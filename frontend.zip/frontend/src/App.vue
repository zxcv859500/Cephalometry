<template>
  <div id="app">
    <Output></Output>
  </div>
</template>

<script>
  import Output from './components/Output'

export default {
  name: 'app',
  components: {
    Output
  }
}
</script>

<style>
</style>
